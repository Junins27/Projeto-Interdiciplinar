if($("#botao-mais").text() === 'Ler mais') {
    $("#botao-mais").text('Ler menos')
  } else {
    $("#botao-mais").text('Ler mais')
  }